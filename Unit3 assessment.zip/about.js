let Buttons = document.querySelectorAll(".crumb")
let Compliments = document.querySelectorAll(".compliment")
let LogoImage = document.querySelector(".LogoImg")
let formEl = document.querySelector("form")

Buttons.forEach(item=>
	{
		item.onmouseover=function(e)
		{
			let X = e.pageX - item.offsetLeft
			let Y = e.pageY - item.offsetTop
			item.style.setProperty("--x", X+"px")
			item.style.setProperty("--y", Y+"px")
			item.style.boxShadow = "0 0 15px aqua"
		}

		item.onmouseout = function()
		{
			item.style.boxShadow="none"
		}
	})

	LogoImage.addEventListener("mouseover", function()
	{
		alert(Compliments[Math.floor(Math.random()*Compliments.length-1)+1].innerHTML)
	})

	formEl.addEventListener("submit", function(e)
	{
		e.preventDefault()
		alert(`Data has been submitted`)
	})






