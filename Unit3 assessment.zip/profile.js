let ToggleButtonEl = document.querySelector(".ToggleButton")
let NavigationMenu = document.querySelector(".NavigationMenu")


ToggleButtonEl.addEventListener("click", function()
{
    ToggleButtonEl.classList.toggle("clicked")
    NavigationMenu.classList.toggle("clicked")
})


let SkillButton = document.querySelector(".SkillButton")
let SkillList = document.querySelector(".SkillList")

SkillButton.addEventListener("click", function(e)
{
    e.preventDefault()
ClearSpace()    
SkillList.classList.toggle("activated")
})


let HobbiesAndInterests = document.querySelector(".HobbiesAndInterests")
let HIButton = document.querySelector(".HIButton")

HIButton.addEventListener("click", function(e)
{
    e.preventDefault()
    ClearSpace()
    HobbiesAndInterests.classList.toggle("activated")
})

let CButton = document.querySelector(".CButton")
let ColorBoxEl = document.querySelector(".ColorBox")

CButton.addEventListener("click", function(e)
{
    e.preventDefault()
   ClearSpace()
    ColorBoxEl.classList.toggle("activated")
})


let FoodBox = document.querySelector(".FoodBox")
let FFButton = document.querySelector(".FFButton")


FFButton.addEventListener("click", function(e)
{
    e.preventDefault()
    ClearSpace()
    FoodBox.classList.toggle("activated")
})

let FMButton = document.querySelector(".FMButton")
let MovieBox = document.querySelector(".MovieBox")

FMButton.addEventListener("click", function(e)
{
    e.preventDefault()
    ClearSpace()
    MovieBox.classList.toggle("activated")
})

let PButton = document.querySelector(".PButton")
let CatBox = document.querySelector(".CatBox")

PButton.addEventListener("click", function(e)
{
    e.preventDefault()
    ClearSpace()
    CatBox.classList.toggle("activated")
})



function ClearSpace()
{
    HobbiesAndInterests.classList.remove("activated")
SkillList.classList.remove("activated")
FoodBox.classList.remove("activated")
MovieBox.classList.remove("activated")
ColorBoxEl.classList.remove("activated")
CatBox.classList.remove("activated")
}